﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSProject1
{
    class Program
    {
        static void Main(string[] args)
        {
            int desicionPlayer, desicionBot;
            // 1=rock, 2= paper, 3= scizzors//


            //intro and those trash stuffs
            Console.WriteLine("Console ROCK PAPER SCIZZORS!!!");
            Console.ReadLine();
            Console.WriteLine("by Mr.StiK_101");
            Console.ReadLine();
            Console.WriteLine("Press 1 for rock, 2 for paper, 3 for scizzors.");

            //player's turn
            desicionPlayer = Convert.ToInt32(Console.ReadLine()); // readline just chosen for strings
            if (desicionPlayer == 1)
            {
                desicionPlayer = 1;  // player choses rock

            }
            else if (desicionPlayer == 2)
            {
                desicionPlayer = 2; // player choses paper

            }
            else if (desicionPlayer == 3)
            {

                desicionPlayer = 3; // player choses scizzors

            }
            else
            {
                Console.WriteLine("This isn't the right option, please restart to play the game and don't repeat the mistake");
            }
            // ai's turn
            //it picks a random choice
            Random DiceRandom = new Random();
            desicionBot = DiceRandom.Next(1, 3);


            //compare the desicions of both player and the ai
            if (desicionPlayer == 1 && desicionBot == 1) // rock, rock
            {
                Console.WriteLine("ROCK and ROCK! \nTie");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 2 && desicionBot == 1) // paper, rock
            {
                Console.WriteLine("PAPER and ROCK \nYOU WON!");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 3 && desicionBot == 1) //scizzors, rock
            {
                Console.WriteLine("SCIZZORS and ROCK \nYOU LOSE!");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 1 && desicionBot == 2) //rock, paper
            {
                Console.WriteLine("ROCK and PAPER \nYOU LOSE");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 2 && desicionBot == 2) // paper, paper
            {
                Console.WriteLine(" PAPER and PAPER \nTie");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 3 && desicionBot == 2) //scizzors, paper
            {
                Console.WriteLine("SCIZZORS and PAPER \n YOU WON!");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 1 && desicionBot == 3) // rock, scizzors
            {
                Console.WriteLine("ROCK and SCIZORS \n YOU WON!");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 2 && desicionBot == 3) // paper, scizzors
            {
                Console.WriteLine("PAPER and SCIZZORS \n YOU LOSE!");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else if (desicionPlayer == 3 && desicionBot == 3) // scizzors, scizzors
            {
                Console.WriteLine("SCIZZORS and SCIZZORS \n Tie!");
                Console.ReadLine();
                Console.WriteLine("Press enter to close.");
            }
            else
            {
                Console.WriteLine("Sorry, but C# finds an error on the A.I bot, probably because of wrong argument.\n Please re open this program and sorry for the inconvineance :(.");
                Console.ReadLine();
            }


            Console.ReadLine();

        }
        // !!!CREDITS!!!
        // Console ROCK PAPER SCIZZORS by Mr.StiK
        // Note: You can play this and enjoy this awesome program
        // Note for code explorers: You are free to use/ copy pasta this code, you can also credit me, it will be appreciated :)

    }
}
